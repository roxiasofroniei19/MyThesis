<template>
    <img src="../../../storage/app/public/img/spinner.gif" alt="" srcset="">
</template>

<style scoped>
    img {
        height: 8%;
        width: 8%;
    }
</style>