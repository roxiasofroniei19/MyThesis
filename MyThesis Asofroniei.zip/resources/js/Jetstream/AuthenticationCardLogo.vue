<template>
    <inertia-link :href="'/'">
        <img src="../../../storage/app/public/img/logo.jpg" alt="logo" class="logo">
    </inertia-link>
</template>

<style scoped>
.logo {
    height: 400px;
    width: 400px;
    border-radius: 10%;
}
</style>
