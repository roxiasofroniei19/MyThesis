<template>
    <img src="../../../storage/app/public/img/logo.jpg" alt="logo">
</template>
