<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <title>Programarile zilei</title>
    <style>
        .logo {
            display: block;
            max-width: 75px;
            margin: 1em auto;
        }

        body {
            font-size: 12px;
        }
    </style>
</head>

<body>
    <div class="container">

        <img src=<?php echo e(public_path('storage/img/logo.jpg')); ?> class="logo">
    </div>
    <div class="p-3 mt-5">
        <h4 class="text-center">Programarile zilei <br> <?php echo e($date); ?></h4>
        <table class="table table-striped mt-5">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Programare</th>
                    <th scope="col">Client</th>
                    <th scope="col">Adresa</th>
                    <th scope="col">Telefon</th>
                    <th scope="col">Ora</th>
                    <th scope="col">Descriere</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $schedules ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->index); ?></th>
                    <td><?php echo e($schedule->ScheduleName); ?></td>
                    <td><?php echo e($schedule->ClientName); ?></td>
                    <td><?php echo e($schedule->ScheduleAddress); ?></td>
                    <td><?php echo e($schedule->ClientPhone); ?></td>
                    <td><?php echo e($schedule->ScheduleTime); ?></td>
                    <td><?php echo e($schedule->ScheduleDescription); ?>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\DeratDezin-Vest\resources\views/pdfSchedulesView.blade.php ENDPATH**/ ?>